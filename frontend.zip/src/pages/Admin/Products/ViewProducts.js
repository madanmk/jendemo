import '../../../css/panel.css';
import ProductNav from './ProductNav';

export default function ViewProducts()
{
      return(
       
            <div className='panel-container'>

                   <ProductNav/>

                    <h2>View Products</h2>

                     <div className='view-format'>
                         
                          <table className="table table-bordered table-hover">

                                <thead>
                                    <tr>
                                      <th>#</th>
                                      <th>Name</th>
                                      <th>Price</th>
                                      <th>Category</th>
                                      <th>Actions</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <tr>
                                      <td>#</td>
                                      <td>Name</td>
                                      <td>Price</td>
                                      <td>Category</td>
                                      <td>Actions</td>
                                    </tr>
                                </tbody>

                          </table>

                     </div>

            </div>
      )
}