import {BrowserRouter,Routes,Route} from 'react-router-dom';
import AdminDashboard from './pages/Admin/AdminDashboard';
import AdminLogin from './pages/Admin/AdminLogin';
import ViewProducts from './pages/Admin/Products/ViewProducts';
import CreateProduct from './pages/Admin/Products/CreateProduct';


function App() {
  return (
    <div className="App">
        
            <BrowserRouter>
                   <Routes>
                         <Route path='adminlogin' element={<AdminLogin/>}/>
                        
                        {/* admin routes*/}
                         <Route path='admindashboard' element={<AdminDashboard/>}>
                                <Route path='/admindashboard/createproduct'element={<CreateProduct/>}/>
                                <Route path='/admindashboard/viewproducts'element={<ViewProducts/>}/>
                          </Route>
                   </Routes>
            </BrowserRouter>

    </div>
  );
}

export default App;
