const express=require('express');
const bcryptjs=require('bcryptjs');
const jwt=require('jsonwebtoken');
const userModel=require("../models/user");
const formidable=require('formidable');
const router=express.Router();


router.post("/create",(req,res)=>{

    let data=req.body;
   
    bcryptjs.genSalt(10,(err,salt)=>{
        
        if(!err){
            bcryptjs.hash(data.password,salt,(err,newpass)=>{

                if(!err){
                    data.password=newpass;
                    
                    userModel.create(data)
                    .then((doc)=>{
                        res.send({success:true,message:"Registration Successfull"});
                    })
                    .catch((err)=>{
                        console.log(err);
                        res.send({success:false,message:"Registration Unsuccessfull try again"});
                    })

                }
                else
                {
                    console.log(err);
                    res.send({success:false,message:"Registration Unsuccessfull try again"});
                }

            })
        }
    })
})

//endpoint for user login
router.post("/login",(req,res)=>{
    let credentials=req.body;

    //based on email id we are finding user logined or not.
       userModel.findOne({email:credentials.email})
       .then((user)=>{

            if(user!==null)
            {  //we are comaparing encrypted pass in backend with frontend user entered pass.
                 bcryptjs.compare(credentials.password,user.password,(err,matched)=>{

                 if(matched===true)
                 { //when we login we generate token using sign() of jsonwebtoken
                   // sign(payload,"secretkey",()=>{}) payload ex:{email} is unique data of user.
                   jwt.sign({email:credentials.email},"secretkey",(err,token)=>{

                        if(!err){
                            res.status(200).send({success:true,token:token,email:user.email,userid:user._id});
                        } 
                        else{
                            console.log(err);
                            res.status(500).send({success:false,message:"Some Issue Happened try again"});
                        }   

                   })

                 }
                 else{
                    res.status(401).send({success:false,message:"Incorrect Password"});
                   }

              })
           }
           else{

              res.status(404).send({success:false,message:"Email Does NOt Exist"});
               }
        })
        .catch((err)=>{
            console.log(err);
            res.status(500).send({success:false,message:"Some Problem with the Server"});
        })

})


//endpoint to update user
router.put("/update/:id",(req,res)=>{

    let id=req.params.id;
    let data=req.body;

    userModel.findyByIdandUpdate(id,data)
    .then((info)=>{
        res.send({success:true,message:"User Update Successfull"});
     })
    .catch((err)=>{
        console.log(err);
        res.send({success:false,message:"Unable to Update User"});
      })

})

/*once we get user we get new prescription and we extract file and store in prescription folder and 
 new presc we update in old stored prescription.*/
router.post("/prescription/:id",async (req,res)=>{

       let id=req.params.id;
       let user=await userModel.findById(id);

       const form=new formidable.IncomingForm();
       //fields is nothing but data.
       form.parse(req,(err,fields,files)=>{

               if(!err) 
               {
                
               }  

       })
})


module.exports=router;