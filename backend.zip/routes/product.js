const express=require('express');
const productModel=require("../models/product");
const cartModel=require("../models/cart");
const router=express.Router();
const formidable=require('formidable');
const fs=require('fs');


//endpoint to read all products
router.get("/",async (req,res)=>{
      
     try{
        let products=await productModel.find();
        res.send({success:true,products})
     }
     catch(err){
        console.log(err);
        res.send({success:false,message:"Unable to fetch product at the moment"});
     }
})

//endpoint to get a single products
router.get("/:product_id",async (req,res)=>{
     
    let product_id=req.params.product_id

    try{
       let products=await productModel.findById(product_id);//find({_id:product_id})
       res.send({success:true,products})
    }
    catch(err){
       console.log(err);
       res.send({success:false,message:"Unable to fetch product at the moment"});
    }
})


//endpoint to create a product
router.post("/create",async (req,res)=>{

        //we create images empty array property in product object to store the FE images which we get in array format.
        let product={images:[]}; 
        console.log(req.body);

         //file uploaded we use formidable to read data in backend.
         const form=new formidable.IncomingForm();
         
         //for multiple files to fetch from FE we use parse first and later addListener() to get "field" and "file" property values
         form.parse(req.body);
         
         form.addListener("field",(property,value)=>{

               product[property]=value;
         })

         form.addListener("file",(property,file)=>{

               let fileData=fs.readFileSync(file.filepath);
               let ext=file.originalFilename.split(".")[1].toUpperCase();
               let newPath=null;
               if(ext==="JPG" || ext==="JPEG" || ext==="PNG")
               {
                   newPath="./products/"+file.newFilename+"."+ext;
                   fs.writeFileSync(newPath,fileData);
               }

               product.images.push(newPath);
                
         })

         form.on("end",()=>{
            console.log(product);
            res.send({message:"All Working"});
         })

       /*  //only if publish property is true,product is published.
         if(product.publish!==undefined && product.publish===true)
         {
             product.approved=true;
         }

         try{
                await productModel.create(product);  
                res.send({success:true,message:"Product Created"});
         }
         catch(err){
            console.log(err);
            res.send({success:false,message:"Unable to create product"});
         }*/

})

//endpoint to update a product
router.put("/update/:product_id",(req,res)=>{

       let product_id=req.params.product_id;
       let data=req.body;

       productModel.updateOne({_id:product_id},data)
       .then((info)=>{
            res.send({success:true,message:"Product Updated successfully"});
        })
      .catch((err)=>{
          console.log(err);
          res.send({message:"unable to Update Product"});
        })

})

//endpoint to delete a product
router.delete("/delete/:product_id",(req,res)=>{

    let product_id=req.params.product_id;
    
    productModel.findByIdAndDelete(product_id)
    .then((info)=>{
         res.send({success:true,message:"Product Deleted successfully"});
     })
   .catch((err)=>{
       console.log(err);
       res.send({message:"unable to Delete Product"});
     })

})

//endpoint to add to cart
router.post("/cart",(req,res)=>{
       let data=req.body;

       cartModel.create(data)
       .then((info)=>{
             res.send({success:true,message:"Product Added to cart"});
         })
      .catch((err)=>{
           console.log(err);
           res.send({message:"unable to Add Product to cart"});
        })

})

//endpoint to remove from cart
router.delete("/cart/:id",(req,res)=>{
  
         let id=req.params.id;
         cartModel.findByIdAndDelete(id)
         .then((info)=>{
                res.send({success:true,message:"Product Removed from cart"});
          })
          .catch((err)=>{
               console.log(err);
               res.send({message:"unable to Remove Product fromcart"});
           })

})


//endpoint to update products in cart
router.put("/cart/:id",(req,res)=>{
  
         let id=req.params.id;
         let data=req.body;
         cartModel.findByIdAndUpdate(id,data)
         .then((info)=>{
               res.send({success:true,message:"Product Updated in cart"});
            })
           .catch((err)=>{
                console.log(err);
                 res.send({message:"unable to Remove Product fromcart"});
             })

})



module.exports=router;