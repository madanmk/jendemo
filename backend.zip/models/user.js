const mongoose=require('mongoose');

const userSchema=mongoose.Schema({

        name:{
            type:String,
            required:true
            },
        email:{
            type:String,
            required:true,
            unique:true
        },
        password:{
            type:String,
            required:true
        },
        gender:{
            type:String,
            required:true,
            enum:["male","female","other"]
        },
        contact:{
            type:String,
            required:true,
            unique:true
        },
        profilePic:{
            type:String,
            default:"",
            required:true,
        },
        addresses:[{type:String}],
        blocked:{
            type:Object,
            required:true,
            default:{block:false,ts:Date.now()}
        },
        prescription:[
            {
                filePath:{
                    type:String
                },
                date:{
                    type:Date,
                    default:Date.now()
                },
                acknowledged:{
                    type:Boolean,
                    default:false
                },
                orderCreated:{
                    type:Boolean,
                    default:false
                }
            }
        ]

},{timestamps:true})

const userModel=mongoose.model("users",userSchema);

module.exports=userModel;