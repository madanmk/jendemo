const mongoose=require('mongoose');

const orderSchema=mongoose.Schema({

       products:[
         {
            type:mongoose.Schema.Types.ObjectId,
            ref:"vendors_products"
         }
       ],
       user:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"users"
          },
        deliveryAddress:{
            type:String,
            required:true
        }
       
},{timestamps:true})

const orderModel=mongoose.model("orders",orderSchema);

module.exports=orderModel;