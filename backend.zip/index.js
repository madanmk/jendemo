const express=require('express');
const mongooose=require('mongoose');
const cors=require('cors');
let PORT=process.env.PORT || 8000;//to considser port which is available in the server if 8000 is not available.

//importing routes
let  adminRouter=require('./routes/admin');
let  categoryRouter=require('./routes/category');
let  productRouter=require('./routes/product');
let  supportRouter=require('./routes/support');
let  userRouter=require('./routes/user');
let  vendorRouter=require('./routes/vendor');

const app=express();

//middleware setup
app.use(cors());
app.use(express.json());

//database connection
mongooose.connect("mongodb://localhost:27017/medplus")
.then(()=>{
    console.log("database connection success");
})

//setting up routes
app.use("/admin",adminRouter);
app.use("/category",categoryRouter);
app.use("/product",productRouter);
app.use("/support",supportRouter);
app.use("/user",userRouter);
app.use("/vendor",vendorRouter);

app.listen(PORT,()=>{
     
      console.log("Server is up and running");

})